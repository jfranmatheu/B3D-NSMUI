WINDOWS: Quadriflow.exe may be not updated, you can compile it by yourself following instructions from official quadriflow git: https://github.com/hjwdzh/QuadriFlow

LINUX AND MAC-OS : you need to compile it by yourself following instructions from official quadriflow git: https://github.com/hjwdzh/QuadriFlow